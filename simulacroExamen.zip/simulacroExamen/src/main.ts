import './style.css'
import { traePaises } from './simulacro'
import type { Pais } from './paises-interface';


document.body.innerHTML = `
  <main>
    <h1>Listado de Paises</h1>
    <button id="ejercicio1">Ejercicio 1</button> 
    <input id="buscador" type="text" placeholder="busqueda por nombre">
    <button id="ejercicio2">Ejercicio 3</button>
    <input id="buscadorFronteras" type="text" placeholder="Pais que comparte frontera"> 
    <button id="idiomas">Ejercicio 4</button>
    <p id="resultadoIdiomas"></p>
    <table id="mi-tabla">
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Capital</th>
          <th>Poblacion</th>
          <th>Idiomas</th>
          <th>Bandera</th>
          <th>Moneda</th>
        </tr>
      </thead>
      <tbody id="tabla-cuerpo">

      </tbody>
    </table>


  </main>
`;


const paises:Pais[] = await traePaises();

const tabla = document.getElementById('tabla-cuerpo') as HTMLElement;
const fitroPoblacion = document.getElementById('ejercicio1') as HTMLButtonElement;
const buscaPais = document.getElementById("buscador") as HTMLInputElement;
const monedaPais = document.getElementById("ejercicio2") as HTMLButtonElement;
const buscaFronteras = document.getElementById("buscadorFronteras") as HTMLInputElement;
const idiomas = document.getElementById("idiomas") as HTMLInputElement;
const resultadoIdiomas = document.getElementById("resultadoIdiomas") as HTMLElement;
idiomas.addEventListener("click", () => {
  const lenguajes:String[] = [];
  paises.forEach((pais) => {
  pais.languages.forEach((idioma) => {

    if (!lenguajes.includes(idioma.name)) {
      lenguajes.push(idioma.name); 
    }
    
  });
  pintarIdiomas(lenguajes);
  
});

});

buscaFronteras.addEventListener("input", () =>{
  const text = buscaFronteras.value.toLowerCase().trim();
  const paisTexto = paises.filter((pais) => pais.name.toLowerCase().trim().includes(text));
  const filtro: Pais[] = paises.filter((pais) =>
  paisTexto.some((paist) => pais.borders?.includes(paist.cioc!))
);
  pintar(filtro);
})


monedaPais.addEventListener("click", () => {
  const filtro:Pais[] = paises.filter((pais) => pais.currencies?.some((moneda) => moneda.name.toLowerCase().includes("euro")));
  
  console.log(filtro);
  
  pintar(filtro);
})


buscaPais.addEventListener("input", () => {
  const texto = buscaPais.value.trim().toLowerCase();

  const filtro = paises.filter((pais) => pais.name.toLowerCase().includes(texto));
  pintar(filtro);
})




fitroPoblacion.addEventListener("click", () =>{
    const filtro:Pais[] = paises.filter((pais) => pais.population > 50000000);
    console.log(filtro);
    
    pintar(filtro);
  })




function pintar(paises:Pais[]):void{
  if (paises.length === 0) {
  tabla.innerHTML = `<tr><td colspan="7">No se han encontrado ningún país</td></tr>`;
} else {
  tabla.innerHTML = paises
    .map(
      (pais) => `
    <tr>
      <td>${pais.name}</td>
      <td>${pais.capital ?? '-'}</td>
      <td>${pais.population}</td>
      <td>${pais.languages?.map((idioma) => idioma.name).join(', ') ?? '-'}</td>
      <td><img src="${pais.flags.png}" alt="Bandera de ${pais.name}" width="40"></td>
      <td>${pais.currencies?.map((moneda) => moneda.name).join(', ') ?? '-'}</td>
      <td>${pais.borders?.join(', ') ?? '-'}</td>
    </tr>`
    )
    .join('');
}
}

function pintarIdiomas(idiomas:String[]){
  resultadoIdiomas.innerHTML = `La cantidad de idiomas que hay diferentes es: ${idiomas.length}`;
}

pintar(paises);


