const URL = 'https://countries.dev/countries';

export async function traePaises<Pais>():Promise<Pais[]>{
    return await fetch(URL).then((response) =>{
        if(!response.ok) throw new Error(`Error codigo de la peticion: ${response.status}` );
        return response.json();
    }).then((data:Pais[]) =>{
        console.log(data);
        return data as Pais[];
    })
}
