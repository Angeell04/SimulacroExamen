export interface Pais {
    area?:              number;
    cioc?:              string;
    flag:               string;
    maps?:              Maps;
    name:               string;
    flags:              Flags;
    latlng?:            number[];
    region:             Region;
    borders?:           string[];
    capital?:           string;
    demonym:            string;
    languages:          Language[];
    subregion:          string;
    timezones:          string[];
    alpha2Code:         string;
    alpha3Code:         string;
    currencies?:        Currency[];
    nativeName:         string;
    population:         number;
    independent:        boolean;
    numericCode:        string;
    altSpellings?:      string[];
    callingCodes:       string[];
    translations:       Translations;
    regionalBlocs?:     RegionalBloc[];
    topLevelDomain:     string[];
    populationDensity?: number;
    gini?:              number;
}

export interface Currency {
    code:   string;
    name:   string;
    symbol: string;
}

export interface Flags {
    png: string;
    svg: string;
}

export interface Language {
    name:        string;
    iso639_1?:   string;
    iso639_2:    string;
    nativeName?: string;
}

export interface Maps {
    googleMaps:     string;
    openStreetMaps: string;
}

export type Region = "Asia" | "Europe" | "Africa" | "Oceania" | "Americas" | "Polar" | "Antarctic Ocean" | "Antarctic";

export interface RegionalBloc {
    name:           Name;
    acronym:        Acronym;
    otherNames?:    OtherName[];
    otherAcronyms?: OtherAcronym[];
}

export type Acronym = "SAARC" | "EU" | "CEFTA" | "AU" | "AL" | "CARICOM" | "USAN" | "EEU" | "CAIS" | "ASEAN" | "NAFTA" | "PA" | "EFTA";

export type Name = "South Asian Association for Regional Cooperation" | "European Union" | "Central European Free Trade Agreement" | "African Union" | "Arab League" | "Caribbean Community" | "Union of South American Nations" | "Eurasian Economic Union" | "Central American Integration System" | "Association of Southeast Asian Nations" | "North American Free Trade Agreement" | "Pacific Alliance" | "European Free Trade Association";

export type OtherAcronym = "UNASUR" | "UNASUL" | "UZAN" | "EAEU" | "SICA";

export type OtherName = "الاتحاد الأفريقي" | "Union africaine" | "União Africana" | "Unión Africana" | "Umoja wa Afrika" | "جامعة الدول العربية" | "Jāmiʻat ad-Duwal al-ʻArabīyah" | "League of Arab States" | "Comunidad del Caribe" | "Communauté Caribéenne" | "Caribische Gemeenschap" | "Unión de Naciones Suramericanas" | "União de Nações Sul-Americanas" | "Unie van Zuid-Amerikaanse Naties" | "South American Union" | "Sistema de la Integración Centroamericana," | "Tratado de Libre Comercio de América del Norte" | "Accord de Libre-échange Nord-Américain" | "Alianza del Pacífico";

export interface Translations {
    br:  string;
    de:  string;
    es:  string;
    fa?: string;
    fr:  string;
    hr:  string;
    hu:  string;
    it:  string;
    ja:  string;
    nl:  string;
    pt:  string;
}
